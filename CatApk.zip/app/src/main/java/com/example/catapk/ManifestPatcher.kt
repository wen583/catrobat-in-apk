package com.example.catapk

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Правка скомпилированного (бинарного) AndroidManifest.xml без сторонних библиотек.
 * Меняет: package (и все строки, где он встречается: authorities, permissions),
 * versionCode, versionName, label приложения и активностей, иконку.
 */
object ManifestPatcher {

    fun patch(
        src: ByteArray, newPkg: String, appName: String,
        verName: String, verCode: Int, iconRes: Int?
    ): ByteArray {
        val b = ByteBuffer.wrap(src.copyOf()).order(ByteOrder.LITTLE_ENDIAN)
        require(b.getShort(0).toInt() == 3) { "Манифест не в бинарном формате" }
        val sp = b.getShort(2).toInt() and 0xFFFF
        require(b.getShort(sp).toInt() == 1) { "Не найден пул строк" }
        val spHeader = b.getShort(sp + 2).toInt() and 0xFFFF
        val spSize = b.getInt(sp + 4)
        val count = b.getInt(sp + 8)
        require(b.getInt(sp + 12) == 0) { "Стили в пуле строк не поддерживаются" }
        val utf8 = (b.getInt(sp + 16) and 0x100) != 0
        val sStart = b.getInt(sp + 20)

        // --- читаем строки ---
        val strs = ArrayList<String>(count + 4)
        for (i in 0 until count) {
            var p = sp + sStart + b.getInt(sp + spHeader + 4 * i)
            if (utf8) {
                val l = b.get(p).toInt() and 0xFF; p++
                if ((l and 0x80) != 0) p++
                var bl = b.get(p).toInt() and 0xFF; p++
                if ((bl and 0x80) != 0) {
                    bl = ((bl and 0x7F) shl 8) or (b.get(p).toInt() and 0xFF); p++
                }
                strs.add(String(b.array(), p, bl, Charsets.UTF_8))
            } else {
                var l = b.getShort(p).toInt() and 0xFFFF; p += 2
                if ((l and 0x8000) != 0) {
                    l = ((l and 0x7FFF) shl 16) or (b.getShort(p).toInt() and 0xFFFF); p += 2
                }
                strs.add(String(b.array(), p, l * 2, Charsets.UTF_16LE))
            }
        }

        fun add(s: String): Int { strs.add(s); return strs.size - 1 }
        fun setType(ap: Int, t: Int) { b.put(ap + 15, t.toByte()) }
        fun setStr(ap: Int, idx: Int) {
            b.putInt(ap + 8, idx); setType(ap, 3); b.putInt(ap + 16, idx)
        }

        var oldPkg: String? = null
        var labelNew = -1
        var oldLabelIdx = -2
        var labelRef = -2

        // --- проходим по элементам ---
        var pos = sp + spSize
        while (pos < b.limit()) {
            val type = b.getShort(pos).toInt() and 0xFFFF
            val size = b.getInt(pos + 4)
            if (type == 0x0102) { // START_ELEMENT
                val name = strs[b.getInt(pos + 20)]
                val aStart = b.getShort(pos + 24).toInt() and 0xFFFF
                val aSize = b.getShort(pos + 26).toInt() and 0xFFFF
                val aCount = b.getShort(pos + 28).toInt() and 0xFFFF
                val base = pos + 16 + aStart
                for (k in 0 until aCount) {
                    val ap = base + k * aSize
                    val an = strs[b.getInt(ap + 4)]
                    val dtype = b.get(ap + 15).toInt() and 0xFF
                    val data = b.getInt(ap + 16)
                    when (name) {
                        "manifest" -> when {
                            an == "package" && dtype == 3 -> oldPkg = strs[data]
                            an == "versionCode" -> {
                                setType(ap, 0x10); b.putInt(ap + 16, verCode); b.putInt(ap + 8, -1)
                            }
                            an == "versionName" && dtype == 3 -> setStr(ap, add(verName))
                        }
                        "application" -> when {
                            an == "label" -> {
                                if (dtype == 3) oldLabelIdx = data else if (dtype == 1) labelRef = data
                                labelNew = add(appName)
                                setStr(ap, labelNew)
                            }
                            (an == "icon" || an == "roundIcon") && iconRes != null -> {
                                setType(ap, 1); b.putInt(ap + 16, iconRes); b.putInt(ap + 8, -1)
                            }
                        }
                        "activity", "activity-alias" ->
                            if (an == "label" && labelNew >= 0 &&
                                ((dtype == 3 && data == oldLabelIdx) || (dtype == 1 && data == labelRef))
                            ) setStr(ap, labelNew)
                    }
                }
            }
            pos += size
        }

        // package -> везде, где он встречается (authorities, permissions...)
        val op = oldPkg
        if (op != null) {
            for (i in strs.indices) if (strs[i].contains(op)) strs[i] = strs[i].replace(op, newPkg)
        }

        // --- собираем новый пул строк ---
        val data = ByteArrayOutputStream()
        val offs = IntArray(strs.size)
        for ((i, s) in strs.withIndex()) {
            offs[i] = data.size()
            if (utf8) {
                val e = s.toByteArray(Charsets.UTF_8)
                len8(data, s.length); len8(data, e.size); data.write(e); data.write(0)
            } else {
                val l = s.length
                if (l > 0x7FFF) { w16(data, 0x8000 or (l shr 16)); w16(data, l and 0xFFFF) } else w16(data, l)
                data.write(s.toByteArray(Charsets.UTF_16LE)); data.write(0); data.write(0)
            }
        }
        while (data.size() % 4 != 0) data.write(0)

        val sStartNew = 28 + 4 * strs.size
        val pool = ByteBuffer.allocate(sStartNew + data.size()).order(ByteOrder.LITTLE_ENDIAN)
        pool.putShort(1); pool.putShort(28)
        pool.putInt(sStartNew + data.size())
        pool.putInt(strs.size); pool.putInt(0)
        pool.putInt(if (utf8) 0x100 else 0)
        pool.putInt(sStartNew); pool.putInt(0)
        for (o in offs) pool.putInt(o)
        pool.put(data.toByteArray())

        val out = ByteArrayOutputStream()
        out.write(b.array(), 0, sp)
        out.write(pool.array())
        out.write(b.array(), sp + spSize, b.limit() - (sp + spSize))
        val res = out.toByteArray()
        ByteBuffer.wrap(res).order(ByteOrder.LITTLE_ENDIAN).putInt(4, res.size)
        return res
    }

    private fun len8(o: ByteArrayOutputStream, n: Int) {
        if (n > 0x7F) { o.write(0x80 or (n shr 8)); o.write(n and 0xFF) } else o.write(n)
    }

    private fun w16(o: ByteArrayOutputStream, v: Int) {
        o.write(v and 0xFF); o.write((v shr 8) and 0xFF)
    }
}
