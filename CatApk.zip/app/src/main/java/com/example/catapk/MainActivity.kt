package com.example.catapk

import android.app.DownloadManager
import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

private enum class Stage { HOME, FORM, SAVING, DONE, ERROR }

@Composable
private fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var stage by remember { mutableStateOf(Stage.HOME) }
    var project by remember { mutableStateOf<Uri?>(null) }
    var icon by remember { mutableStateOf<Uri?>(null) }
    var name by remember { mutableStateOf("") }
    var pkg by remember { mutableStateOf("org.catrobat.standalone.myapp") }
    var verName by remember { mutableStateOf("1.0") }
    var verCode by remember { mutableStateOf("1") }
    var result by remember { mutableStateOf<Uri?>(null) }
    var error by remember { mutableStateOf("") }

    val pickProject = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) {
        if (it != null) {
            project = it
            name = ApkBuilder.displayName(ctx, it).removeSuffix(".catrobat")
            stage = Stage.FORM
        }
    }
    val pickIcon = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
        if (it != null) icon = it
    }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        when (stage) {
            Stage.HOME -> {
                Spacer(Modifier.weight(1f))
                Text("Pocket Code → APK", style = MaterialTheme.typography.headlineMedium)
                Text("Выбери экспортированный файл .catrobat")
                Button(onClick = { pickProject.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth()) {
                    Text("Найти файл")
                }
                Spacer(Modifier.weight(1f))
            }

            Stage.FORM -> {
                Text("Параметры приложения", style = MaterialTheme.typography.titleLarge)
                OutlinedTextField(name, { name = it }, label = { Text("Название") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(pkg, { pkg = it }, label = { Text("Package name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(verName, { verName = it }, label = { Text("Версия (versionName)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(verCode, { verCode = it.filter(Char::isDigit) }, label = { Text("Код версии (versionCode)") }, modifier = Modifier.fillMaxWidth())
                OutlinedButton(onClick = { pickIcon.launch("image/*") }, Modifier.fillMaxWidth()) {
                    Text(if (icon == null) "Выбрать иконку" else "Иконка выбрана ✓")
                }
                Spacer(Modifier.weight(1f))
                Button(
                    enabled = name.isNotBlank() && pkg.matches(Regex("[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+")) && verCode.isNotEmpty(),
                    onClick = {
                        stage = Stage.SAVING
                        scope.launch {
                            try {
                                result = withContext(Dispatchers.IO) {
                                    ApkBuilder.build(ctx, ApkConfig(project!!, name, pkg, verName, verCode.toInt(), icon))
                                }
                                stage = Stage.DONE
                            } catch (e: Throwable) {
                                error = (e.message ?: e.toString()) + "\n\n" + e.stackTrace.take(14).joinToString("\n"); stage = Stage.ERROR
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Сохранить") }
            }

            Stage.SAVING -> {
                Spacer(Modifier.weight(1f))
                CircularProgressIndicator()
                Text("Идёт сохранение…")
                Spacer(Modifier.weight(1f))
            }

            Stage.DONE -> {
                Spacer(Modifier.weight(1f))
                Text("Готово! APK сохранён в «Загрузки»", style = MaterialTheme.typography.titleMedium)
                Button(onClick = {
                    try {
                        if (!ctx.packageManager.canRequestPackageInstalls()) {
                            Toast.makeText(ctx, "Разреши установку для этого приложения, потом нажми «Установить» ещё раз", Toast.LENGTH_LONG).show()
                            ctx.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName)))
                        } else {
                            ctx.startActivity(Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(result, "application/vnd.android.package-archive")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                            })
                        }
                    } catch (e: Exception) {
                        Toast.makeText(ctx, "Не удалось открыть установщик. Открой APK из папки Загрузки", Toast.LENGTH_LONG).show()
                    }
                }, Modifier.fillMaxWidth()) { Text("Установить") }
                OutlinedButton(onClick = {
                    try {
                        ctx.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) {
                        Toast.makeText(ctx, "APK лежит в папке Загрузки", Toast.LENGTH_LONG).show()
                    }
                }, Modifier.fillMaxWidth()) { Text("Открыть Загрузки") }
                OutlinedButton(onClick = { stage = Stage.HOME }, Modifier.fillMaxWidth()) { Text("В меню") }
                Spacer(Modifier.weight(1f))
            }

            Stage.ERROR -> {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    Text("Ошибка: $error", color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall)
                }
                OutlinedButton(onClick = { stage = Stage.FORM }, Modifier.fillMaxWidth()) { Text("Назад") }
            }
        }
    }
}
