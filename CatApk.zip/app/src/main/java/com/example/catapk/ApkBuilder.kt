package com.example.catapk

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns
import com.android.apksig.ApkSigner
import pxb.android.axml.AxmlReader
import pxb.android.axml.AxmlVisitor
import pxb.android.axml.AxmlWriter
import pxb.android.axml.NodeVisitor
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FilterOutputStream
import java.io.OutputStream
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class ApkConfig(
    val project: Uri,
    val appName: String,
    val pkg: String,
    val versionName: String,
    val versionCode: Int,
    val icon: Uri?
)

/**
 * Берёт ШАБЛОН плеера (assets/player_template.apk — standalone-сборка Catroid),
 * подменяет в нём манифест (package/label/version), иконку, кладёт проект
 * в assets/project.catrobat, подписывает и сохраняет в Загрузки.
 */
object ApkBuilder {
    private const val TEMPLATE = "player_template.apk"
    private const val PROJECT_IN_APK = "assets/project.catrobat"
    // Путь иконки внутри шаблона — ПРОВЕРЬ по своему шаблону (unzip -l player_template.apk)
    private const val ICON_PATH = "res/mipmap-xxhdpi-v4/ic_launcher.png"
    private const val KEYSTORE = "signing.p12"   // положи в assets, alias "key", пароль "android"

    fun displayName(ctx: Context, uri: Uri): String =
        ctx.contentResolver.query(uri, null, null, null, null)?.use {
            val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (it.moveToFirst() && i >= 0) it.getString(i) else null
        } ?: "project"

    fun build(ctx: Context, c: ApkConfig): Uri {
        val unsigned = File(ctx.cacheDir, "unsigned.apk")
        val signed = File(ctx.cacheDir, "signed.apk")

        val projectBytes = ctx.contentResolver.openInputStream(c.project)!!.use { it.readBytes() }
        val iconBytes = c.icon?.let { iconPng(ctx, it) }

        Counting(unsigned.outputStream().buffered()).use { counter ->
            ZipOutputStream(counter).use { zout ->
                ZipInputStream(ctx.assets.open(TEMPLATE)).use { zin ->
                    var e = zin.nextEntry
                    while (e != null) {
                        val n = e.name
                        if (!e.isDirectory && !n.startsWith("META-INF/")) {
                            val data = zin.readBytes()
                            when {
                                n == "AndroidManifest.xml" -> put(zout, counter, n, patchManifest(data, c), false)
                                n == ICON_PATH && iconBytes != null -> put(zout, counter, n, iconBytes, false)
                                else -> put(zout, counter, n, data, n == "resources.arsc" || n.endsWith(".so"))
                            }
                        }
                        e = zin.nextEntry
                    }
                }
                put(zout, counter, PROJECT_IN_APK, projectBytes, false)
            }
        }

        sign(ctx, unsigned, signed)
        return saveToDownloads(ctx, signed, c.appName)
    }

    // --- запись zip; resources.arsc и .so — STORED с выравниванием по 4 байта ---
    private fun put(z: ZipOutputStream, cnt: Counting, name: String, data: ByteArray, stored: Boolean) {
        val e = ZipEntry(name)
        if (stored) {
            e.method = ZipEntry.STORED
            e.size = data.size.toLong(); e.compressedSize = data.size.toLong()
            e.crc = CRC32().also { it.update(data) }.value
            val pad = ((4 - (cnt.n + 30 + name.length) % 4) % 4).toInt()
            if (pad > 0) e.extra = ByteArray(pad)
        }
        z.putNextEntry(e); z.write(data); z.closeEntry()
    }

    private class Counting(o: OutputStream) : FilterOutputStream(o) {
        var n = 0L
        override fun write(b: Int) { out.write(b); n++ }
        override fun write(b: ByteArray, off: Int, len: Int) { out.write(b, off, len); n += len }
    }

    // --- манифест ---
    private fun patchManifest(src: ByteArray, c: ApkConfig): ByteArray {
        val writer = AxmlWriter()
        AxmlReader(src).accept(object : AxmlVisitor(writer) {
            override fun child(ns: String?, name: String?): NodeVisitor =
                Edit(super.child(ns, name), name, c)
        })
        return writer.toByteArray()
    }

    private class Edit(nv: NodeVisitor?, val tag: String?, val c: ApkConfig) : NodeVisitor(nv) {
        override fun attr(ns: String?, name: String?, res: Int, type: Int, obj: Any?) {
            var t = type
            val v: Any? = when {
                tag == "manifest" && name == "package" -> c.pkg
                tag == "manifest" && name == "versionCode" -> c.versionCode
                tag == "manifest" && name == "versionName" -> c.versionName
                tag == "application" && name == "label" -> { t = 3 /* TYPE_STRING */; c.appName }
                else -> obj
            }
            super.attr(ns, name, res, t, v)
        }
        override fun child(ns: String?, name: String?): NodeVisitor = Edit(super.child(ns, name), name, c)
    }

    // --- иконка ---
    private fun iconPng(ctx: Context, uri: Uri): ByteArray {
        val bmp = ctx.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it) }
        val scaled = Bitmap.createScaledBitmap(bmp, 144, 144, true) // подгони под размер из шаблона
        return ByteArrayOutputStream().also { scaled.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
    }

    // --- подпись ---
    private fun sign(ctx: Context, input: File, output: File) {
        val pw = "android".toCharArray()
        val ks = KeyStore.getInstance("PKCS12").apply { load(ctx.assets.open(KEYSTORE), pw) }
        val key = ks.getKey("key", pw) as PrivateKey
        val chain = ks.getCertificateChain("key").map { it as X509Certificate }
        ApkSigner.Builder(listOf(ApkSigner.SignerConfig.Builder("cat", key, chain).build()))
            .setInputApk(input).setOutputApk(output).setMinSdkVersion(24).build().sign()
    }

    // --- в «Загрузки» ---
    private fun saveToDownloads(ctx: Context, f: File, appName: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, "${appName.replace(Regex("[^A-Za-z0-9_-]"), "_")}.apk")
            put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)!!
        ctx.contentResolver.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        return uri
    }
}
