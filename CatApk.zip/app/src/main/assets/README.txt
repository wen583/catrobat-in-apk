Сюда кладётся player_template.apk (standalone-плеер Catroid).
signing.p12 создаётся автоматически при сборке на GitHub.
